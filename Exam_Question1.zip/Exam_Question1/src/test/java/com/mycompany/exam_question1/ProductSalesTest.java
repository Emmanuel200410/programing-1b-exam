/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.exam_question1;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_Lab
 */
public class ProductSalesTest {
    
    public ProductSalesTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of TotalSales method, of class ProductSales.
     */
    
    @Test
    public void CalculateTotalSales_ReturnsTotalSales() {
        // Arrange
        int[][] testSales = {
            {300, 150, 700},
            {250, 200, 600}
        };
        ProductSales salesCalculator = new ProductSales();
       
        // Act
        int result = salesCalculator.TotalSales(testSales);
       
        // Assert
        assertEquals(2200, result);
    }
   
    @Test
    public void AverageSales_ReturnsAverageProductsSales() {
        // Arrange
        int[][] testSales = {
            {300, 150, 700},
            {250, 200, 600}
        };
        ProductSales salesCalculator = new ProductSales();
       
        // Act
        double result = salesCalculator.AverageSales(testSales);
       
        // Assert
        assertEquals(366.66, result, 0.01); // Allowing for small rounding differences
    }
   
    @Test
    public void testTotalSales() {
        System.out.println("TotalSales");
        int[][] productsSales = {
            {300, 150, 700},
            {250, 200, 600}
        };
        ProductSales instance = new ProductSales();
        int expResult = 2200;
        int result = instance.TotalSales(productsSales);
        assertEquals(expResult, result);
    }

    @Test
    public void testAverageSales() {
        System.out.println("AverageSales");
        int[][] productsSales = {
            {300, 150, 700},
            {250, 200, 600}
        };
        ProductSales instance = new ProductSales();
        double expResult = 366.66;
        double result = instance.AverageSales(productsSales);
        assertEquals(expResult, result, 0.01);
    }

    @Test
    public void testMaxSale() {
        System.out.println("MaxSale");
        int[][] productsSales = {
            {300, 150, 700},
            {250, 200, 600}
        };
        ProductSales instance = new ProductSales();
        int expResult = 700;
        int result = instance.MaxSale(productsSales);
        assertEquals(expResult, result);
    }

    @Test
    public void testMinSale() {
        System.out.println("MinSale");
        int[][] productsSales = {
            {300, 150, 700},
            {250, 200, 600}
        };
        ProductSales instance = new ProductSales();
        int expResult = 150;
        int result = instance.MinSale(productsSales);
        assertEquals(expResult, result);
    }
   
    // Additional edge case tests
    @Test
    public void testTotalSalesWithNull() {
        System.out.println("TotalSales with null");
        int[][] productsSales = null;
        ProductSales instance = new ProductSales();
        int expResult = 0;
        int result = instance.TotalSales(productsSales);
        assertEquals(expResult, result);
    }
   
    @Test
    public void testAverageSalesWithNull() {
        System.out.println("AverageSales with null");
        int[][] productsSales = null;
        ProductSales instance = new ProductSales();
        double expResult = 0.0;
        double result = instance.AverageSales(productsSales);
        assertEquals(expResult, result, 0.0);
    }
}