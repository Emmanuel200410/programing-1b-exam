/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exam_question1;

/**
 *
 * @author RC_Student_Lab
 */
public class Exam_Question1 {

    public static void main(String[] args) {
   // Product sales data for two years
        int[][] productSales = {
            {300, 150, 700}, // Year 1
            {250, 200, 600}  // Year 2
        };
       
        // Create ProductSales instance
        ProductSales sale = new ProductSales();
       
        // Calculate statistics
        int totalSales = sale.TotalSales(productSales);
        double averageSales = sale.AverageSales(productSales);
        int maxSale = sale.MaxSale(productSales);
        int minSale = sale.MinSale(productSales);
       
        // Display the report
        System.out.println("============================");
        System.out.println("PRODUCT SALES REPORT - 2025");
        System.out.println("============================");
        System.out.println("Total sales: " + totalSales);
        System.out.println("Average sales: " + averageSales);
        System.out.println("Maximum sales: " + maxSale);
        System.out.println("Minimum sales: " + minSale);
    }
}
