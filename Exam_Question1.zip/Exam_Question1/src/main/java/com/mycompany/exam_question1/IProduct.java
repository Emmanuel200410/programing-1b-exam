/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.exam_question1;

/**
 *
 * @author RC_Student_Lab
 */
interface IProduct {
 
    int TotalSales(int[][] productsSales);
    double AverageSales(int[][] productsSales);
    int MaxSale(int[][] productsSales);
    int MinSale(int[][] productsSales);
}

