/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exam_question1;

/**
 *
 * @author RC_Student_Lab
 */
class ProductSales implements IProduct {
    

   
    @Override
    public int TotalSales(int[][] productsSales) {
        int total = 0;
        for (int i = 0; i < productsSales.length; i++) {
            for (int j = 0; j < productsSales[i].length; j++) {
                total += productsSales[i][j];
            }
        }
        return total;
    }
   
    @Override
    public double AverageSales(int[][] productsSales) {
        int total = TotalSales(productsSales);
        int count = 0;
        for (int i = 0; i < productsSales.length; i++) {
            count += productsSales[i].length;
        }
        return (double) total / count;
    }
   
    @Override
    public int MaxSale(int[][] productsSales) {
        int max = productsSales[0][0];
        for (int i = 0; i < productsSales.length; i++) {
            for (int j = 0; j < productsSales[i].length; j++) {
                if (productsSales[i][j] > max) {
                    max = productsSales[i][j];
                }
            }
        }
        return max;
    }
   
    @Override
    public int MinSale(int[][] productsSales) {
        int min = productsSales[0][0];
        for (int i = 0; i < productsSales.length; i++) {
            for (int j = 0; j < productsSales[i].length; j++) {
                if (productsSales[i][j] < min) {
                    min = productsSales[i][j];
                }
            }
        }
        return min;
    }
}
