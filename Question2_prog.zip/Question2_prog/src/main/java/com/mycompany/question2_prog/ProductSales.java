/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.question2_prog;

/**
 *
 * @author RC_Student_Lab
 */
public class ProductSales  implements IProductSales {
    

    private final int[][] productSales; // rows = years, cols = products
    private final int salesLimit;

    public ProductSales(int[][] productSales, int salesLimit) {
        // defensive copy
        this.productSales = new int[productSales.length][productSales[0].length];
        for (int i = 0; i < productSales.length; i++) {
            System.arraycopy(productSales[i], 0, this.productSales[i], 0, productSales[i].length);
        }
        this.salesLimit = salesLimit;
    }

    @Override
    public int[][] GetProductSales() {
        // return defensive copy
        int[][] copy = new int[productSales.length][productSales[0].length];
        for (int i = 0; i < productSales.length; i++) {
            System.arraycopy(productSales[i], 0, copy[i], 0, productSales[i].length);
        }
        return copy;
    }

    @Override
    public int GetTotalSales() {
        int total = 0;
        for (int[] year : productSales) {
            for (int sale : year) total += sale;
        }
        return total;
    }

    @Override
    public double GetAverageSales() {
        int total = GetTotalSales();
        int count = productSales.length * productSales[0].length;
        if (count == 0) return 0;
        return (double) total / count;
    }

    @Override
    public int GetSalesOverLimit() {
        int count = 0;
        for (int[] year : productSales) {
            for (int sale : year) {
                if (sale > salesLimit) count++;
            }
        }
        return count;
    }

    @Override
    public int GetSalesUnderLimit() {
        int count = 0;
        for (int[] year : productSales) {
            for (int sale : year) {
               
                if (sale < salesLimit) count++;
            }
        }
        return count;
    }

    @Override
    public int GetProductsProcessed() {
       
        return productSales.length;
    }
}

