/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question2_prog;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

/**
 *
 * @author RC_Student_Lab
 */
public class Question2_prog extends JFrame{
  

 
            
    private final JTextArea textArea = new JTextArea(8, 30);
    private final JLabel yearsLabel = new JLabel("Years Processed: 0");
    private final JButton loadButton = new JButton("Load Product Data");
    private final JButton saveButton = new JButton("Save Product Data");

    // sample data from the assignment
    private final int[][] sampleData = {
        // Microphone, Speakers, Mixing Desk
        {300, 150, 700}, // Year 1
        {250, 200, 600}  // Year 2
    };

    private final int SALES_LIMIT = 500;

    // NOTE: constructor name must match class name
    public Question2_prog() {
        super("Product Sales Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        // Top panel with buttons
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(3, 1, 4, 4));
        topPanel.add(loadButton);
        topPanel.add(saveButton);

        // center with text area inside a scroll pane
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);

        // bottom with years label
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        bottomPanel.add(yearsLabel);

        setJMenuBar(createMenuBar());
        add(topPanel, BorderLayout.WEST);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // button actions
        loadButton.addActionListener(e -> loadProductData());
        saveButton.addActionListener(e -> saveProductData());

        setSize(520, 300);
        setLocationRelativeTo(null);
    }

    private JMenuBar createMenuBar() {
        JMenuBar mb = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem loadItem = new JMenuItem("Load Product Data");
        JMenuItem saveItem = new JMenuItem("Save Product Data");
        JMenuItem clearItem = new JMenuItem("Clear");

        loadItem.addActionListener(e -> loadProductData());
        saveItem.addActionListener(e -> saveProductData());
        clearItem.addActionListener(e -> clearData());

        toolsMenu.add(loadItem);
        toolsMenu.add(saveItem);
        toolsMenu.addSeparator();
        toolsMenu.add(clearItem);

        mb.add(fileMenu);
        mb.add(toolsMenu);
        return mb;
    }

    private void loadProductData() {
        
        ProductSales ps = new ProductSales(sampleData, SALES_LIMIT);

        StringBuilder sb = new StringBuilder();
        sb.append("Product Sales Data:\n");
        sb.append("------------------------------\n");

        // header: product names
        String[] products = {"Microphone", "Speakers", "Mixing Desk"};
        for (int y = 0; y < sampleData.length; y++) {
            sb.append("Sales for year ").append(y + 1).append(": ");
            for (int p = 0; p < sampleData[y].length; p++) {
                sb.append(products[p]).append(" ").append(sampleData[y][p]);
                if (p < sampleData[y].length - 1) sb.append(", ");
            }
            sb.append("\n");
        }
        sb.append("\n");

        sb.append("Total Sales: ").append(ps.GetTotalSales()).append("\n");
        sb.append("Average Sales: ").append(Math.round(ps.GetAverageSales())).append("\n");
        sb.append("Sales over limit: ").append(ps.GetSalesOverLimit()).append("\n");
        sb.append("Sales under limit: ").append(ps.GetSalesUnderLimit()).append("\n");

        textArea.setText(sb.toString());
        yearsLabel.setText("Years Processed: " + ps.GetProductsProcessed());
    }

    private void saveProductData() {
        String content = textArea.getText();
        if (content == null || content.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No data to save. Please load product data first.", "No Data", JOptionPane.WARNING_MESSAGE);
            return;
        }

        
        File file = new File("data.txt");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(file))) {
            bw.write("DATA LOG\n");
            bw.write("******************************\n");
            bw.write(content);
            bw.write("******************************\n");
            bw.flush();
             JOptionPane.showMessageDialog(yearsLabel, "Report saved successfully to report.txt!");
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(yearsLabel, "Error saving report: " + ex.getMessage());
        }
    }

    private void clearData() {
        textArea.setText("");
        yearsLabel.setText("Years Processed: 0");
    }

    public static void main(String[] args) {
        // Create and show the GUI by instantiating the GUI class (Question2_prog)
        SwingUtilities.invokeLater(() -> {
            Question2_prog app = new Question2_prog();
            app.setVisible(true);
        });
    }
}

