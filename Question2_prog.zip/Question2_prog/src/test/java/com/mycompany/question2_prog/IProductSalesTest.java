/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.question2_prog;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_Lab
 */
public class IProductSalesTest {
    
    public IProductSalesTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of GetProductSales method, of class IProductSales.
     */
    @Test
    public void testGetProductSales() {
        System.out.println("GetProductSales");
        IProductSales instance = new IProductSalesImpl();
        int[][] expResult = null;
        int[][] result = instance.GetProductSales();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetTotalSales method, of class IProductSales.
     */
    @Test
    public void testGetTotalSales() {
        System.out.println("GetTotalSales");
        IProductSales instance = new IProductSalesImpl();
        int expResult = 0;
        int result = instance.GetTotalSales();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetSalesOverLimit method, of class IProductSales.
     */
    @Test
    public void testGetSalesOverLimit() {
        System.out.println("GetSalesOverLimit");
        IProductSales instance = new IProductSalesImpl();
        int expResult = 0;
        int result = instance.GetSalesOverLimit();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetSalesUnderLimit method, of class IProductSales.
     */
    @Test
    public void testGetSalesUnderLimit() {
        System.out.println("GetSalesUnderLimit");
        IProductSales instance = new IProductSalesImpl();
        int expResult = 0;
        int result = instance.GetSalesUnderLimit();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetProductsProcessed method, of class IProductSales.
     */
    @Test
    public void testGetProductsProcessed() {
        System.out.println("GetProductsProcessed");
        IProductSales instance = new IProductSalesImpl();
        int expResult = 0;
        int result = instance.GetProductsProcessed();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetAverageSales method, of class IProductSales.
     */
    @Test
    public void testGetAverageSales() {
        System.out.println("GetAverageSales");
        IProductSales instance = new IProductSalesImpl();
        double expResult = 0.0;
        double result = instance.GetAverageSales();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class IProductSalesImpl implements IProductSales {

        public int[][] GetProductSales() {
            return null;
        }

        public int GetTotalSales() {
            return 0;
        }

        public int GetSalesOverLimit() {
            return 0;
        }

        public int GetSalesUnderLimit() {
            return 0;
        }

        public int GetProductsProcessed() {
            return 0;
        }

        public double GetAverageSales() {
            return 0.0;
        }
    }
    
}
