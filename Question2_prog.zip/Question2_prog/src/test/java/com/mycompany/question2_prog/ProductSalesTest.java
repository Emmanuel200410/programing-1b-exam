/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.question2_prog;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_Lab
 */
public class ProductSalesTest {
    
    public ProductSalesTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of GetProductSales method, of class ProductSales.
     */
    @Test
    public void testGetProductSales() {
        System.out.println("GetProductSales");
        ProductSales instance = null;
        int[][] expResult = null;
        int[][] result = instance.GetProductSales();
        assertArrayEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetTotalSales method, of class ProductSales.
     */
    @Test
    public void testGetTotalSales() {
        System.out.println("GetTotalSales");
        ProductSales instance = null;
        int expResult = 0;
        int result = instance.GetTotalSales();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetAverageSales method, of class ProductSales.
     */
    @Test
    public void testGetAverageSales() {
        System.out.println("GetAverageSales");
        ProductSales instance = null;
        double expResult = 0.0;
        double result = instance.GetAverageSales();
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetSalesOverLimit method, of class ProductSales.
     */
    @Test
    public void testGetSalesOverLimit() {
        System.out.println("GetSalesOverLimit");
        ProductSales instance = null;
        int expResult = 0;
        int result = instance.GetSalesOverLimit();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetSalesUnderLimit method, of class ProductSales.
     */
    @Test
    public void testGetSalesUnderLimit() {
        System.out.println("GetSalesUnderLimit");
        ProductSales instance = null;
        int expResult = 0;
        int result = instance.GetSalesUnderLimit();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of GetProductsProcessed method, of class ProductSales.
     */
    @Test
    public void testGetProductsProcessed() {
        System.out.println("GetProductsProcessed");
        ProductSales instance = null;
        int expResult = 0;
        int result = instance.GetProductsProcessed();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
